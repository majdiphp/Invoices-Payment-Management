-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 21, 2023 at 06:22 AM
-- Server version: 5.7.40
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inv`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` char(14) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `vat` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `email`, `address`, `phone`, `contact`, `vat`) VALUES
(5, 'Majdi', 'majdiawad371@gmail.com', 'Nahda, Dubai, UAE', '00971505411579', 'Majdi Awad', '-'),
(6, 'GCS', 'hasan@itisae.com', 'Dubai, UAE', '0563041393', 'hasan', '1234567891235'),
(7, 'KTS', 'info@kts.ae', 'Al Moroor St. Abu Dhabi, UAE', '00971505411579', 'Khaled Awad', '1234567891235');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
CREATE TABLE IF NOT EXISTS `company` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` char(14) NOT NULL,
  `vat` varchar(255) NOT NULL,
  `bank_ad` text NOT NULL,
  `iban` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `name`, `email`, `address`, `phone`, `vat`, `bank_ad`, `iban`) VALUES
(4, 'ITIS Ajman', 'info@itisae.com', 'Rawdah 2, Ajman, UAE', '00971505411579', '1234567891235', '', '123456782');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
CREATE TABLE IF NOT EXISTS `invoices` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `client_id` smallint(6) NOT NULL,
  `product_id` tinyint(4) NOT NULL,
  `company_id` tinyint(4) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `total` smallint(6) NOT NULL,
  `date` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoices_ibfk_1` (`client_id`),
  KEY `invoices_ibfk_2` (`product_id`),
  KEY `invoices_ibfk_3` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `client_id`, `product_id`, `company_id`, `comments`, `total`, `date`) VALUES
(3, 6, 3, 4, 'Test Invoice 01', 3000, '2023/02/21'),
(4, 5, 6, 4, 'Test Invoice 2', 27000, '2023/02/21'),
(5, 5, 7, 4, 'Test Invoice 03', 1500, '2023/02/21'),
(6, 7, 4, 4, 'Test Invoice 04', 3000, '2023/02/21');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
CREATE TABLE IF NOT EXISTS `payments` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `inv_id` smallint(6) NOT NULL,
  `paid` varchar(15) NOT NULL,
  `remaining` varchar(15) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_ibfk_1` (`inv_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `inv_id`, `paid`, `remaining`, `status`) VALUES
(10, 3, '3000', '0', 'Paid'),
(11, 4, '20000', '7000', 'UnPaid'),
(12, 5, '1500', '0', 'Paid'),
(13, 6, '200', '2800', 'UnPaid');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `vendor` varchar(255) NOT NULL,
  `stock` smallint(6) NOT NULL,
  `purchasing_price` smallint(6) NOT NULL,
  `sale_price` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `type`, `vendor`, `stock`, `purchasing_price`, `sale_price`) VALUES
(2, 'Web Design', 'Sevice', 'ITIS', 100, 200, 1500),
(3, 'Web Development', 'Sevice', 'ITIS', 1000, 100, 10000),
(4, 'Web Hosting', 'Sevice', 'ITIS', 1000, 100, 500),
(5, 'Web Application', 'Sevice', 'ITIS', 1000, 100, 3000),
(6, 'HickVision', 'Product', 'ITIS', 1000, 100, 150),
(7, 'D-link Switch', 'Product', 'D-link', 1000, 100, 2200),
(8, 'IoT', 'Sevice', 'ITIS', 1000, 100, 20000);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` char(32) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `name`) VALUES
(1, 'majdi@itisae.com', 'Majdi@00800', 'Majdi Awad');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `invoices_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `invoices_ibfk_3` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`inv_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
