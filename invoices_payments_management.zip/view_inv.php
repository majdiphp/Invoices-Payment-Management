<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />

		<title>ITIS Invoices</title>

		<!-- Favicon -->
		<link rel="icon" href="./images/favicon.ico" type="image/x-icon" />

		<!-- Invoice styling -->
		<style>
			body {
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				text-align: center;
				color: #777;
			}

			body h1 {
				font-weight: 300;
				margin-bottom: 0px;
				padding-bottom: 0px;
				color: #000;
			}

			body h3 {
				font-weight: 300;
				margin-top: 10px;
				margin-bottom: 20px;
				font-style: italic;
				color: #555;
			}

			body a {
				color: #06f;
			}

			.invoice-box {
				max-width: 800px;
				margin: auto;
				padding: 30px;
				border: 1px solid #eee;
				box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
				font-size: 16px;
				line-height: 24px;
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				color: #555;
			}

			.invoice-box table {
				width: 100%;
				line-height: inherit;
				text-align: left;
				border-collapse: collapse;
			}

			.invoice-box table td {
				padding: 5px;
				vertical-align: top;
			}

			.invoice-box table tr td:nth-child(2) {
				text-align: right;
			}

			.invoice-box table tr.top table td {
				padding-bottom: 20px;
			}

			.invoice-box table tr.top table td.title {
				font-size: 45px;
				line-height: 0px;
				color: #333;
			}

			.invoice-box table tr.information table td {
				padding-bottom: 40px;
			}

			.invoice-box table tr.heading td {
				background: #eee;
				border-bottom: 1px solid #ddd;
				font-weight: bold;
			}

			.invoice-box table tr.details td {
				padding-bottom: 20px;
			}

			.invoice-box table tr.item td {
				border-bottom: 1px solid #eee;
			}

			.invoice-box table tr.item.last td {
				border-bottom: none;
			}

			.invoice-box table tr.total td:nth-child(2) {
				border-top: 2px solid #eee;
				font-weight: bold;
			}

			@media only screen and (max-width: 600px) {
				.invoice-box table tr.top table td {
					width: 100%;
					display: block;
					text-align: center;
				}

				.invoice-box table tr.information table td {
					width: 100%;
					display: block;
					text-align: center;
				}
			}
		</style>
	</head>

	<body>
	
		<!-- Prepare the PHP -->
		<?php
		// Import required pgaes
		include 'application/config/db_config.php';
		include 'application/queries/queries.php';
		
		// Fetch Objects
		// get invoice id
		$id = $_GET['id'];
		// date
		$inv_date = mysqli_query($conn,"SELECT * FROM invoices WHERE id = '$id'");
		if($inv_date->num_rows) {
		$d = $inv_date->fetch_object();
		}
		// bank account
		// date
		$bank = mysqli_query($conn,"SELECT i.company_id, c.id, c.bank_ad FROM invoices as i JOIN company as c WHERE i.company_id = c.id");
		if($bank->num_rows) {
		$ba = $bank->fetch_object();
		}
		// iban
		$iban = mysqli_query($conn,"SELECT i.company_id, c.id, c.iban, c.name, c.address, c.vat FROM invoices as i JOIN company as c WHERE i.company_id = c.id");
		if($iban->num_rows) {
		$ib = $iban->fetch_object();
		}
		// Client Info
		$cinfo = mysqli_query($conn,"SELECT cl.name, cl.address, cl.phone, i.id FROM clients as cl JOIN invoices as i WHERE i.client_id = cl.id");
		if($cinfo->num_rows) {
		$ci = $cinfo->fetch_object();
		}
		// items
		$item = mysqli_query($conn,"SELECT p.id, p.name, i.id FROM products as p JOIN invoices as i WHERE i.product_id = p.id");
		if($item->num_rows) {
		$ip = $item->fetch_object();
		}
		// prices
		$price = mysqli_query($conn,"SELECT total FROM invoices WHERE id = '$id'");
		if($price->num_rows) {
		$pr = $price->fetch_object();
		}
		?>
		<!-- End prepare the PHP -->
		<!-- Start The Invoice -->
		<div class="invoice-box">
			<table>
				<tr class="top">
					<td colspan="2">
						<table>
							<tr>
								<td class="title">
									<h2>ITIS AE</h2>
								</td>

								<td>
									Invoice #: 2023-02-01-0000<?php echo $id; ?><br />
									Issued date: <?php echo $d->date; ?><br />
									Bank Account: <?php echo $ba->bank_ad; ?><br />
									IBAN: <?php echo $ib->iban; ?>
								</td>
							</tr>
						</table>
					</td>
				</tr>

				<tr class="information">
					<td colspan="2">
						<table>
							<tr>
								<td>
									From: <?php echo $ib->name; ?><br />
									<?php echo $ib->address; ?><br />
									Vat: <?php echo $ib->vat; ?>
								</td>

								<td>
									To: <?php echo $ci->name; ?><br />
									<?php echo $ci->address; ?><br />
									<?php echo $ci->phone; ?>
								</td>
							</tr>
						</table>
					</td>
				</tr>


				<tr class="heading">
					<td>Item</td>
					<td>Price</td>
				</tr>

				<tr class="item">
					<td><?php echo $ip->name; ?></td>

					<td><?php echo $pr->total; ?></td>
				</tr>


				<tr class="total">
					<td></td>

					<td>Total: <?php echo $pr->total; ?></td>
				</tr>
				<tr class="total">
					<td></td>

					<td>Tax: 5%</td>
				</tr>
				<tr class="total">
					<td></td>
					<?php
						$vat = $pr->total * 0.05;
					?>
					<td>Due Amount: <?php echo $pr->total + $vat; ?></td>
				</tr>
			</table>
			<tr class="top">
					<td colspan="2">
						<table>


				<tr class="information">
					<td colspan="2">
						<table>
							<tr>
								<td>
									This invoice generated by ITIS Invoices system V-0.0.1<br>
									You can pay cash, PayPal, or Bank Transfer<br>
									Thank you for your businss.
								</td>
						</table>
		</div>
	</body>
</html>
