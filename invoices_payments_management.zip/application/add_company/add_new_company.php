<?php

include '../config/db_config.php';

$name = $_POST['name'];
$email = $_POST['email'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$vat = $_POST['vat'];
$bank_ad = $_POST['bank_ad'];
$iban = $_POST['iban'];

$add_company = "INSERT INTO company (name, email, address, phone, vat, bank_ad, iban) VALUES ('$name', '$email', '$address', '$phone', '$vat', '$vank_ad', '$iban')";

if ($conn->query($add_company) === TRUE) {
header ('Location: ../../settings.php');
} else {
echo "Error: " . $sql . "<br>" . $conn->error;
}
?>

