<?php

include '../config/db_config.php';

$id = $_GET['id'];
$delete_product = "DELETE FROM products WHERE id='$id'";

if ($conn->query($delete_product) === TRUE) {
  header ('Location: ../../services.php');
} else {
  echo '<script type="text/javascript">';
  echo ' alert("This Product cannot be deleted because it is linked to invoices or payments.")';
  echo '</script>';
}

$conn->close();
?> 