<?php

	$invoices = mysqli_query($conn,"SELECT * FROM invoices");
	$payments = mysqli_query($conn,"SELECT * FROM payments");
	$products = mysqli_query($conn,"SELECT * FROM products");
	$clients = mysqli_query($conn,"SELECT * FROM clients");
	$users = mysqli_query($conn,"SELECT * FROM users");
	$company = mysqli_query($conn,"SELECT * FROM company");
	// get the sum of all paid column values
	$income = mysqli_query($conn,"SELECT SUM(paid) as total FROM payments");
	$row = mysqli_fetch_assoc($income); 
	$sum = $row['total'];
	// get the sum of all remaining column values
	$remaining = mysqli_query($conn,"SELECT SUM(remaining) as total_remaining FROM payments");
	$row = mysqli_fetch_assoc($remaining); 
	$remain = $row['total_remaining'];
	
	// Invoice Table Query (SQL Join)
	
	$inv_table = mysqli_query($conn,"SELECT i.id as inv_num, i.client_id, i.product_id, c.name as client_name, c.id, p.sale_price as price, p.name as product_name, p.id, co.name as company_name, i.comments, i.total FROM invoices AS i join clients AS c join products AS p join company AS co where i.client_id = c.id AND i.product_id = p.id order by i.id desc; ");
	
	$products_inv = mysqli_query($conn,"SELECT SUM(sale_price) as total FROM products");
	

	
