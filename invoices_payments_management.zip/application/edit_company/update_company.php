<?php

include '../config/db_config.php';

$id = $_POST['id'];
$name = $_POST['name'];
$email = $_POST['email'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$vat = $_POST['vat'];
$bank_ad = $_POST['bank_ad'];
$iban = $_POST['iban'];


$update_company = "UPDATE company SET id='$id', name='$name', email='$email', address='$address', phone='$phone', vat='$vat', bank_ad='$bank_ad', iban='$iban' WHERE id=$id";

if ($conn->query($update_company) === TRUE) {
  header ('Location: ../../settings.php');
} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();
?> 
