<?php

include '../config/db_config.php';

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];


$add_users = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";

if ($conn->query($add_users) === TRUE) {
header ('Location: ../../users.php');
} else {
echo "Error: " . $sql . "<br>" . $conn->error;
}
?>

