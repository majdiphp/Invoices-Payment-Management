<?php

include '../config/db_config.php';

$id = $_POST['id'];
$name = $_POST['name'];
$type = $_POST['type'];
$vendor = $_POST['vendor'];
$stock = $_POST['stock'];
$purchasing_price = $_POST['purchasing_price'];
$sale_price = $_POST['sale_price'];

$update_product = "UPDATE products SET id='$id', name='$name', type='$type', vendor='$vendor', stock='$stock', purchasing_price='$purchasing_price', sale_price='$sale_price' WHERE id=$id";

if ($conn->query($update_product) === TRUE) {
  header ('Location: ../../services.php');
} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();
?> 
