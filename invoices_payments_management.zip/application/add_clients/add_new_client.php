<?php

include '../config/db_config.php';

$name = $_POST['name'];
$email = $_POST['email'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$contact = $_POST['contact'];
$vat = $_POST['vat'];

$add_client = "INSERT INTO clients (name, email, address, phone, contact, vat) VALUES ('$name', '$email', '$address', '$phone', '$contact', '$vat')";

if ($conn->query($add_client) === TRUE) {
header ('Location: ../../clients.php');
} else {
echo "Error: " . $sql . "<br>" . $conn->error;
}
?>

