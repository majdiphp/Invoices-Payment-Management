<?php

include '../config/db_config.php';

$id = $_GET['id'];
$delete_company = "DELETE FROM company WHERE id='$id'";

if ($conn->query($delete_company) === TRUE) {
  header ('Location: ../../settings.php');
} else {
  echo '<script type="text/javascript">';
  echo ' alert("This customer cannot be deleted because it is linked to invoices and payments.")';
  echo '</script>';
}

$conn->close();
?> 