<?php
// Inqlude the php pages
include '../config/db_config.php';
include '../queries/queries.php';

// use global variable to get data from form
$inv_id = $_POST['inv_id'];
$paid_amt = $_POST['paid_amt'];

// get the total for the invoice from invoices table to calculate remaining and know the status
// The following sql is asking for the total were the value of the ID column = the value of the inv_id (entered by user) 
$remaining_status = mysqli_query($conn,"SELECT total FROM invoices where id = '$inv_id'");
// fetch_object to use the objects
if($remaining_status->num_rows) {
	$r = $remaining_status->fetch_object();
}	
// save the invoice total value in a variable to use it later
$invoice_total = $r->total;

// calculate remaining
if($paid_amt < $invoice_total) {
	$rm = $invoice_total - $paid_amt;
} else {
	$rm = '0';
}
// calculate status
if($paid_amt < $invoice_total) {
	$st = 'UnPaid';
} else {
	$st = 'Paid';
}

// insert the data into payments table
$add_payment = "INSERT INTO payments (inv_id, paid, remaining, status) VALUES ('$inv_id', '$paid_amt', '$rm', '$st')";

if ($conn->query($add_payment) === TRUE) {
header ('Location: ../../payments.php');
} else {
echo "Error: " . $add_payment . "<br>" . $conn->error;
}
?>



