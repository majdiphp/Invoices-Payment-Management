<?php

include '../config/db_config.php';
include '../queries/queries.php';

$inv_id = $_POST['inv_id'];
$paid_amt = $_POST['paid_amt'];

// get data from the invoices table
$rs = mysqli_query($conn,"SELECT * FROM invoices where id = '$inv_id'");
if($rs->num_rows) {
	$r = $rs->fetch_object();
}
$total_inv = $r->total;
// calculate remaining
if($paid_amt < $total_inv) {
	$rm = $total_inv - $paid_amt;
} else {
	$rm = '0';
}
// calculate status
if($paid_amt = $total_inv) {
	$st = 'Paid';
} else {
	$st = 'Unpaid';
}

$add_payment = "INSERT INTO payments (inv_id, paid, remaining, status) VALUES ('$inv_id', '$paid_amt', '$rm', '$st')";

if ($conn->query($add_payment) === TRUE) {
header ('Location: ../../payments.php');
} else {
echo "Error: " . $add_payment . "<br>" . $conn->error;
}
?>
