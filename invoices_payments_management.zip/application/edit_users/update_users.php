<?php

include '../config/db_config.php';

$id = $_POST['id'];
$name = $_POST['name'];
$email = $_POST['email'];
$passwor = $_POST['password'];

$update_user = "UPDATE users SET id='$id', name='$name', email='$email', password='$password' WHERE id=$id";

if ($conn->query($update_user) === TRUE) {
  header ('Location: ../../users.php');
} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();
?> 
