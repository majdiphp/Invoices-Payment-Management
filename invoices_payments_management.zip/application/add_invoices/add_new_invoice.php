<?php

include '../config/db_config.php';
include '../queries/queries.php';

$client_id = $_POST['client_id'];
$product_id = $_POST['product_id'];
$quatity = $_POST['quatity'];
$company_id = $_POST['company_id'];
$comments = $_POST['comments'];
$date = $_POST['date'];


// get total price
if($products->num_rows) {
	$r = $products->fetch_object();
}

$total = $r->sale_price * $quatity;

$add_inv = "INSERT INTO invoices (client_id, product_id, company_id, comments, total, date) VALUES ('$client_id', '$product_id', '$company_id', '$comments', '$total', '$date')";

if ($conn->query($add_inv) === TRUE) {
header ('Location: ../../invoices.php');
} else {
echo "Error: " . $add_inv . "<br>" . $conn->error;
}
?>
