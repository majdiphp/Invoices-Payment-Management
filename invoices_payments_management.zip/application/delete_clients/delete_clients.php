<?php

include '../config/db_config.php';

$id = $_GET['id'];
$delete_client = "DELETE FROM clients WHERE id='$id'";

if ($conn->query($delete_client) === TRUE) {
  header ('Location: ../../clients.php');
} else {
  echo '<script type="text/javascript">';
  echo ' alert("This customer cannot be deleted because it is linked to invoices and payments.")';
  echo '</script>';
}

$conn->close();
?> 