<?php

include '../config/db_config.php';

$id = $_POST['id'];
$name = $_POST['name'];
$email = $_POST['email'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$contact = $_POST['contact'];
$vat = $_POST['vat'];

$update_client = "UPDATE clients SET id='$id', name='$name', email='$email', address='$address', phone='$phone', contact='$contact', vat='$vat' WHERE id=$id";

if ($conn->query($update_client) === TRUE) {
  header ('Location: ../../clients.php');
} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();
?> 
