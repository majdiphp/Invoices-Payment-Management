﻿<?php
/*
##########################################################################################################################
The layout designed based on sufee-admin-dashboard-master and modified by Majdi Awad.
The back-end (PHP & SQL) created by Majdi Awad without any framework. It's pure PHP and SQL Project.
##########################################################################################################################
*/
include '../config/db_config.php';
// Use the global variables to save the entered values in variables

$email = $_POST['email'];
$password = $_POST['password'];

// normal SELECT sentence

$login = mysqli_query($conn,"SELECT email, password FROM users WHERE email='$email' AND password='$password'");

// Check if username and password are correct

if($login->num_rows > 0) {

	header ('Location: ../../dashboard.php');
	
	} else {
			
		echo "Wrong Username or Password";
		
		}
/*
##########################################################################################################################
The layout designed based on sufee-admin-dashboard-master and modified by Majdi Awad.
The back-end (PHP & SQL) created by Majdi Awad without any framework. It's pure PHP and SQL Project.
##########################################################################################################################
*/
?>