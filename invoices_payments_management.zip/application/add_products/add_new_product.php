<?php

include '../config/db_config.php';

$name = $_POST['name'];
$type = $_POST['type'];
$vendor = $_POST['vendor'];
$stock = $_POST['stock'];
$purchasing_price = $_POST['purchasing_price'];
$sale_price = $_POST['sale_price'];

$add_product = "INSERT INTO products (name, type, vendor, stock, purchasing_price, sale_price) VALUES ('$name', '$type', '$vendor', '$stock', '$purchasing_price', '$sale_price')";

if ($conn->query($add_product) === TRUE) {
header ('Location: ../../services.php');
} else {
echo "Error: " . $add_product . "<br>" . $conn->error;
}
?>

