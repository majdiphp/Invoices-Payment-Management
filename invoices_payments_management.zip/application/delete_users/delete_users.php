<?php

include '../config/db_config.php';

$id = $_GET['id'];
$delete_users = "DELETE FROM users WHERE id='$id'";

if ($conn->query($delete_users) === TRUE) {
  header ('Location: ../../users.php');
} else {
  echo '<script type="text/javascript">';
  echo ' alert("This Product cannot be deleted because it is linked to invoices or payments.")';
  echo '</script>';
}

$conn->close();
?> 