<!--
##########################################################################################################################
The layout designed based on sufee-admin-dashboard-master and modified by Majdi Awad.
The back-end (PHP & SQL) created by Majdi Awad without any framework. It's pure PHP and SQL Project.
##########################################################################################################################
-->

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ITIS Invoices Management System</title>
    <meta name="description" content="ITIS Invoices Management System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Favicon start -->  
	<link rel="apple-touch-icon" sizes="144x144" href="apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
	<link rel="manifest" href="site.webmanifest">
	<meta name="msapplication-TileColor" content="#da532c">
	<meta name="theme-color" content="#ffffff">
	<!-- Favicon end -->

    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">


    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>


    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <h3 style="color:#fff;">ITIS INVOICES</h3>
                <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
					<li>
                        <a href="clients.php"> <i class="menu-icon fa fa-users"></i>Clients </a>
                    </li>
					<li class="active">
                        <a href="services.php"> <i class="menu-icon fa fa-cog"></i>Services / Products </a>
                    </li>
					<li>
                        <a href="invoices.php"> <i class="menu-icon fa fa-file"></i>Invoices </a>
                    </li>
					<li>
                        <a href="payments.php"> <i class="menu-icon fa fa-money"></i>Payments </a>
                    </li>
					<li>
                        <a href="reports.php"> <i class="menu-icon fa fa-bar-chart-o"></i>Reports </a>
                    </li>
					<li>
                        <a href="settings.php"> <i class="menu-icon fa fa-cog"></i>Settings </a>
                    </li>
					<li>
                        <a href="users.php"> <i class="menu-icon fa fa-user"></i>Users </a>
                    </li>
					<li>
                        <a href="index.php"> <i class="menu-icon fa fa-sign-out"></i>Logout </a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                        <h2>Products / Services</h2>
					</div>

        </header><!-- /header -->
        <!-- Header-->
		<!-- Include PHP files -->
			<?php
				include 'application/config/db_config.php';
				include 'application/queries/queries.php';
			?>
		<!-- END connect to the database + write the queries -->
        <div class="content mt-3">
			            <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title"><a href="add_product.php"><button type="button" class="btn btn-primary">Add Service or Product</button></a></strong>
                            </div>
                            <div class="card-body">
                                <table class="table">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Type</th>
                                            <th scope="col">Vendor</th>
											<th scope="col">Stock</th>
											<th scope="col">Purchasing Price</th>
											<th scope="col">Sale Price</th>
											<th scope="col">Edit</th>
											<th scope="col">Delete</th>
                                        </tr>
                                    </thead>
							        <?php
        
									if($products->num_rows) {
										while($r = $products->fetch_object()) {
										?>
										<tbody>
                                        <tr>
                                            <th scope="row"><?php echo $r->id; ?></th>
                                            <td><?php echo $r->name; ?></td>
                                            <td><?php echo $r->type; ?></td>
                                            <td><?php echo $r->vendor; ?></td>
											<td><?php echo $r->stock; ?></td>
											<td><?php echo $r->purchasing_price; ?></td>
											<td><?php echo $r->sale_price; ?></td>
											<td><a href="edit_product.php?id=<?php echo $r->id; ?>">Edit</a></td>
											<td><a href="application/delete_products/delete_products.php?id=<?php echo $r->id; ?>">Delete</a></td>
                                        </tr>										
										<?php

										}
									}
								
							?>
                            </div>
                        </div>
                    </div>

        </div> <!-- .content -->
            </div><!--/.col-->
            </div><!--/.col-->
			</div> <!-- .content -->
			
    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/chart.js/dist/Chart.bundle.min.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="vendors/jqvmap/dist/jquery.vmap.min.js"></script>
    <script src="vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <script src="vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script>
        (function($) {
            "use strict";

            jQuery('#vmap').vectorMap({
                map: 'world_en',
                backgroundColor: null,
                color: '#ffffff',
                hoverOpacity: 0.7,
                selectedColor: '#1de9b6',
                enableZoom: true,
                showTooltip: true,
                values: sample_data,
                scaleColors: ['#1de9b6', '#03a9f5'],
                normalizeFunction: 'polynomial'
            });
        })(jQuery);
    </script>

</body>

</html>
